<!DOCTYPE html>
<!-- saved from url=(0032)file:///A:/project/himanshu.html -->
<html lang="en" class="fa-events-icons-failed"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>SVVV</title>    
    
    <link href="font-awesome.min.css" type="text/css" rel="stylesheet">    
    
    <link href="himanshu_files/vendors.css" type="text/css" rel="stylesheet">
    <link href="himanshu_files/style.css" type="text/css" rel="stylesheet" id="style">
    <link href="file:///A:/project/himanshu_files/components.css" type="text/css" rel="stylesheet" id="components">    
    <link rel="stylesheet" type="text/css" href="file:///A:/project/himanshu_files/color-switch.css">    

    <link href="file:///A:/project/himanshu_files/settings.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="flayers.css">
    <link rel="stylesheet" type="text/css" href="file:///A:/project/himanshu_files/navigation.css">
    <link href="file:///A:/project/himanshu_files/jquery.imageview.css" type="text/css" rel="stylesheet">    
    
    <link href="himanshu_files/css" rel="stylesheet" type="text/css">
    <link href="himanshu_files/css(1)" rel="stylesheet" type="text/css">
    <link href="/himanshu_files/css(2)" rel="stylesheet" type="text/css">
    <script type="text/javascript" async="" src="./newhimanshu_files/analytics.js.download"></script><script type="text/javascript" async="" src="file:///A:/project/himanshu_files/analytics.js.download"></script><script src="file:///A:/project/himanshu_files/28dfbc73b4.js.download"></script><link href="./newhimanshu_files/28dfbc73b4.css" media="all" rel="stylesheet"><link href="himanshu_files/28dfbc73b4.css" media="all" rel="stylesheet">
    
      <!-- Global site tag (gtag.js) - Google Analytics -->
<script async="" src="file:///A:/project/himanshu_files/js"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-116011046-2');
</script>
  
    
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async="" src="file:///A:/project/himanshu_files/js(1)"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-53493337-1');
</script>

    <link href="file:///A:/project/himanshu_files/bootstrap.min.css" type="text/css" rel="stylesheet">    
  <!--  <script type="text/javascript" src="htts://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>    -->
<script>
    $( document ).ready(function() {
    function sliceSize(dataNum, dataTotal) {
        //alert ('hello');
  return (dataNum / dataTotal) * 360;
}
function addSlice(sliceSize, pieElement, offset, sliceID, color) {
  $(pieElement).append("<div class='slice "+sliceID+"'><span></span></div>");
  var offset = offset - 1;
  var sizeRotation = -179 + sliceSize;
  $("."+sliceID).css({
    "transform": "rotate("+offset+"deg) translate3d(0,0,0)"
  });
  $("."+sliceID+" span").css({
    "transform"       : "rotate("+sizeRotation+"deg) translate3d(0,0,0)",
    "background-color": color
  });
}
function iterateSlices(sliceSize, pieElement, offset, dataCount, sliceCount, color) {
  var sliceID = "s"+dataCount+"-"+sliceCount;
  var maxSize = 179;
  if(sliceSize<=maxSize) {
    addSlice(sliceSize, pieElement, offset, sliceID, color);
  } else {
    addSlice(maxSize, pieElement, offset, sliceID, color);
    iterateSlices(sliceSize-maxSize, pieElement, offset+maxSize, dataCount, sliceCount+1, color);
  }
}
function createPie(dataElement, pieElement) {

  var listData = [];

  $(dataElement+" span").each(function() {

    listData.push(Number($(this).html()));

  });

  var listTotal = 0;

  for(var i=0; i<listData.length; i++) {

    listTotal += listData[i];

  }

  var offset = 0;

  var color = [

    "cornflowerblue",
    "olivedrab",
    "orange", 
    "tomato", 
    "crimson", 
    "purple", 
    "turquoise", 
    "forestgreen", 
    "navy", 
    "gray"
  ];
  for(var i=0; i<listData.length; i++) {
    var size = sliceSize(listData[i], listTotal);
    iterateSlices(size, pieElement, offset, i, 0, color[i]);
    $(dataElement+" li:nth-child("+(i+1)+")").css("border-color", color[i]);
    offset += size;
  }
}
createPie(".pieID.legend", ".pieID.pie");
});
</script>
<style type="text/css">
.left_side{
  margin-left: 80px;
}
  .logomobile
  {
   width: 176%;
   margin-left: -92px;
  }
@media only screen and (max-width: 500px) {
   .logomobile
  {
    width: 80% !important;
    margin-left: -10px !important;
  }
  .topheadercss
{
  display: none !important;
}
}
</style>
  <link rel="stylesheet" type="text/css" href="file:///A:/project/himanshu_files/style.css"><link rel="stylesheet" type="text/css" href="file:///A:/project/himanshu_files/components.css"><link rel="stylesheet" type="text/css" href="./newhimanshu_files/style.css"><link rel="stylesheet" type="text/css" href="./newhimanshu_files/components.css"></head>
  <body class="home" style="">        
    <!-- <div class="loader-backdrop">
        <div class="loader">
            <div class="ball-1"></div>
            <div class="ball-2"></div>
        </div>
    </div> -->        
  <header>  
        <div class="topbar topheadercss "> 
           <div class="container">
                <div class="row visible-lg">
                 <div class="col-md-3">
                      <img src="C:\xampp\htdocs\himanshu\project\himanshu_files\Apple_School.png" class="img-responsive appleid" style="margin-left: 35px;">
                    </div> 
                   <div class="col-md-6 head-margin left_side visible-lg">
                       <div class="col-md-5">
                          <div class="col-md-1">
                         <i class="fa fa-phone fa-fw email txt-centr" aria-hidden="true" style="    font-size: 45px;"></i>
                        </div>
                        <div class="col-md-10">
                          <a href="tel:+919300110033" class="call-us txt-centr">+919522237602</a>
                          <a href="tel:+919300110033" class="call-us txt-centr">+919522237604 </a>
                        </div>
                        </div>
                        <div class="col-md-7">
                          <div class="col-md-2"><i class="fa fa-envelope fa-fw email" style="    font-size: 45px;margin-left:-15px;"></i></div>
                          <div class="col-md-10"><a href="mailto:test@example.com" class="email"><span> admission@svvv.edu.in</span></a>
      </div>
                        </div>    
                    </div>                  
                    <div class="col-md-2 head-margin visible-lg">
                          <div class="col-md-1">
                         <i class="fa fa-map-marker fa-fw email txt-centr" aria-hidden="true" style=" font-size: 45px;"></i>
                        </div>
                        <div class="col-offset-md-2 col-md-8">
                         <a href="https://www.google.com/maps?ll=21.283762,76.198797&amp;z=16&amp;t=m&amp;hl=en-US&amp;gl=IN&amp;mapclient=embed&amp;cid=107308611447843243" target="_blank" class="email" style="float:right;margin-top: 5px;">
                        <span style="font-size: 19px;">Locate Us</span></a>
                        </div>
                        </div>
                           <!--       <div class="col-sm-2 head-margin">

                        <center>

                            <div class="col-md-3">

                                <i class="fa fa-envelope fa-fw head_color head-icon1"></i>

                            </div>

                            <div class="col-md-8">

                                <a href="mailto:test@example.com" class="email"><span class=" head_color"> mvisionacademy@gmail.com</span></a> 

                                <a href="mailto:test@example.com" class="email"><span class=" head_color">info@mvaburhanpur.com</span></a>

                            </div>

                        </center>      

                    </div>

                    <div class="col-sm-3">

                      <img src="http://mvaburhanpur.com/front_theme/images/Apple_School.png" class="img-responsive apple_image">

                    </div> -->

                    <!-- <div class="col-offset-sm-1 col-sm-1 top-margin head-margin" style="cursor: pointer;">                       

                        <div class="col-xs-offset-1 col-sm-2 col-xs-2">

                            <a href="http://mvaburhanpur.com/User/apple_ipad" title="Apple IPAD"><i class="fa fa-apple head-icon" aria-hidden="true"></i></a>

                        </div> -->

                       <!--  <div class="col-sm-1 col-xs-2">

                            <a href="http://mvaburhanpur.com/User/complaint_box" title="Complaint Box"><i class="fa fa-archive head-icon" aria-hidden="true"></i></a>

                        </div> -->

                        <!-- <div class="col-sm-2 col-xs-2">

                            <a href="http://mvaburhanpur.com/User/virtual_tour" title="Virtual Tour"><i class="fa fa-plane head-icon" aria-hidden="true"></i></a>

                        </div>

                    </div> -->

                  <!--   <div class="col-offset-sm-1 col-sm-2" style="margin-top: 10px;">

                       <center><h5><a style="color: #fff;" href="http://mvaburhanpur.com/User/locate_us">Locate Us</a></h5></center>

                    </div>

                    <div class="col-offset-sm-1 col-sm-2" style="margin-top: 10px; float: right">

                      <span style="color:#fff;">Font Size Increase/Decrease</span>

                        <input type="button" class="increase" value=" + ">

                        <input type="button" class="decrease" value=" - "/>

                        <input type="button" class="resetMe" value=" = ">

                    </div> -->



                        <!-- <div>

  <p style="font-size : 30px">This text is initially 30px</p>

  <div>

    <p style="font-size : 20px">This text is initially 20px</p>

    <p style="font-size : 10px">This text is initially 10px</p>

    

  </div>  

</div> -->



<!-- <button id="btn-decrease">A-</button>

<button id="btn-orig">A</button>

<button id="btn-increase">A+</button> -->

                    

                    

                </div>

            </div>

        </div>        

        <nav class="navbar navbar-default">         <!-- Navigation Bar -->

            <div class="container">

                <div class="row">

                <div class="navbar-header col-md-3">

                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-navigation" aria-expanded="false">

                        <span class="sr-only">Toggle Menu</span>

                        <span>Menu</span>

                    </button>


                         <a class="navbar-brand " href="file:///C:/xampp/htdocs/himanshu/project/himanshu.html"><img src="C:\xampp\htdocs\himanshu\project\himanshu_files\logo.png" class="logomobile" alt=""></a>

                     

                  
                   <!--  <a class="navbar-brand" href="file:///A:/project/himanshu.html"><img src="http://mvaburhanpur.com/front_theme/images/logo.png" alt="" class="logo-head"></a> -->

                </div>                

                <div class="collapse navbar-collapse col-md-9" id="main-navigation">

                    <ul class="nav navbar-nav navbar-right nav-margin">


                        <li><a href="javascript:void(0);">About</a>

                            <ul class="sub-menu">

                                <li><a href="javascript:void(0);">SVVV</a>

                                   <ul class="sub-menu">

                                      <li><a href="file:///C:/xampp/htdocs/himanshu/project/aboutus.html">About Us</a></li>

                                  
                                    </ul>

                                </li> 

                                <li><a href="javascript:void(0);">Campus &amp;Facilities</a>

                                 <ul class="sub-menu">

                                    <li><a href="file:///C:/xampp/htdocs/himanshu/project/accomodation.html">Accomodation</a></li>

                                    <li><a href="file:///C:/xampp/htdocs/himanshu/project/facilities.html">Facilities</a></li>

                                    <li><a href="file:///C:/xampp/htdocs/himanshu/project/infrastructures.html">Infrastructure</a></li>

                                  </ul>

                                </li> 

                                </li>  


                            </ul>

                        </li>

                        <li><a href="file:///C:/xampp/htdocs/himanshu/project/whyus.html">Why Us</a>

                        </li>

                       

                        <li><a href="http://mvaburhanpur.com/User/gallery">Gallery</a>

                        </li>   

                         <li><a href="javascript:void(0);">Students Requirements</a>
                            <ul class="sub-menu">                                 
                                                                 
                             <li><a href="javascript:void(0);">Academics</a>
                            <ul class="sub-menu">                                 
                                <li><a href="http://mvaburhanpur.com/User/result">Syllabus</a></li>
                                 <li><a href="http://mvaburhanpur.com/User/current_result">Time-Table</a></li> 
                                <li><a href="http://mvaburhanpur.com/User/scholarship">Previous year papers</a></li>
                                </ul>
                            </li>
   
                               
                                <li><a href="http://mvaburhanpur.com/User/scholarship">Scholarship</a></li>
                                
                              
                            </ul>
                        </li>                     
                        
                        <li><a href="http://mvaburhanpur.com/User/today_in_mva">Today in SVVV</a>
                        </li>
                       <!--  <li><a href="http://mvaburhanpur.com/User/teaching_staff">Teaching Staff</a></li> -->
                        <li><a href="javascript:void(0);">Apply</a>
                          <ul class="sub-menu">
                                <li><a href="http://localhost/himanshu/project/form%20main.php">Registration for college</a></li>
                             
                            </ul>
                        </li>
                       
                        </li>
                          
                        <li><a href="javascript:void(0);">Job Opportunities</a>
                            <ul class="sub-menu">                                 
                               
   <li><a href="javascript:void(0);">B.Tech/M.Tech</a>
                            <ul class="sub-menu">                                 
                                <li><a href="http://mvaburhanpur.com/User/result">CSE</a></li>
                                 <li><a href="http://mvaburhanpur.com/User/current_result">Mechanical</a></li> 
                                <li><a href="http://mvaburhanpur.com/User/scholarship">Civil</a></li>
                                                      <li><a href="http://mvaburhanpur.com/User/scholarship">Electronics/Electrical</a></li>
                      
                      <li><a href="http://mvaburhanpur.com/User/scholarship">IT</a></li>

                              
                            </ul>
                        </li>    
        
<li><a href="javascript:void(0);">B.Sc/M.Sc</a>
                            <ul class="sub-menu">                                 
                                <li><a href="http://mvaburhanpur.com/User/result">Physics</a></li>
                                 <!-- <li><a href="http://mvaburhanpur.com/User/current_result">Chemistry</a></li> -->
                                <li><a href="http://mvaburhanpur.com/User/scholarship">Maths</a></li>
                                                      <li><a href="http://mvaburhanpur.com/User/scholarship">Statics</a></li>
                      <li><a href="http://mvaburhanpur.com/User/scholarship">Electrical</a></li>
                      <li><a href="http://mvaburhanpur.com/User/scholarship">IT</a></li>

                              
                            </ul>
                        </li>    
                                 <li><a href="http://mvaburhanpur.com/User/current_result">B.Arch</a></li> 
                                <li><a href="http://mvaburhanpur.com/User/scholarship">BCA/MCA</a></li>

                                
                              
                            </ul>
                        </li>             
                        
                        <li><a href="file:///C:/xampp/htdocs/himanshu/project/himanshu.html">Admission Enquiry</a>
                            <ul class="sub-menu">
                           
                               
                            </ul>
                        </li>
                        <li><a href="http://mvaburhanpur.com/User/contact_us">Contact</a>
                        </li>

                        <li><a href="http://localhost/himanshu/project/login.php">Admin Database</a>
                        
                    </ul>
                </div>
            </div>
            </div>
        </nav>
    </header>
    <script type="text/javascript" language="javascript" src="file:///A:/project/himanshu_files/jquery-latest.min.js.download"></script>   
  <script type="text/javascript">
 $(document).ready(function(){
  // var originalSize = $('div').css('font-size');
  // reset
   $(".resetMe").click(function(){
  //$('div').css('font-size', originalSize); 
  location.reload();
   });
   // Increase Font Size
   $(".increase").click(function(){
    var currentSize = $('div').css('font-size');
    //alert(currentSize);
    var currentSize1 = $('p').css('font-size'); 
    var currentSize2 = $('h1').css('font-size'); 
    var currentSize3 =$('h2').css('font-size'); 
    var currentSize4 =$('h3').css('font-size'); 
    var currentSize5 =$('h4').css('font-size'); 
    var currentSize6 =$('h5').css('font-size'); 
    var currentSize7 =$('h6').css('font-size');
    var currentSize8 =$('span').css('font-size');  
    var currentSize9 =$('a').css('font-size'); 
    var currentSize10 =$('table').css('font-size');
  var currentSize = parseFloat(currentSize)*1.2;
  var currentSize1 = parseFloat(currentSize1)*1.2;
  var currentSize2 = parseFloat(currentSize2)*1.2;
  var currentSize3 = parseFloat(currentSize3)*1.2;
  var currentSize4 = parseFloat(currentSize4)*1.2;
  var currentSize5 = parseFloat(currentSize5)*1.2;
  var currentSize6 = parseFloat(currentSize6)*1.2;
  var currentSize7 = parseFloat(currentSize7)*1.2;
  var currentSize8 = parseFloat(currentSize8)*1.2;
  var currentSize9 = parseFloat(currentSize9)*1.2;
  var currentSize10 = parseFloat(currentSize10)*1.2;
  $('div').css('font-size', currentSize);
  $('p').css('font-size', currentSize1);
  $('h1').css('font-size', currentSize2);
  $('h2').css('font-size', currentSize3);
  $('h3').css('font-size', currentSize4);
  $('h4').css('font-size', currentSize5);
  $('h5').css('font-size', currentSize6);
  $('h6').css('font-size', currentSize7);
  $('span').css('font-size', currentSize8);
  $('a').css('font-size', currentSize9);
  $('table').css('font-size', currentSize10);
  return false;
   });
   // Decrease Font Size
   $(".decrease").click(function(){
  //var currentFontSize = $('div').css('font-size');
  var currentSize = $('div').css('font-size');
  var currentSize1 = $('p').css('font-size');
  var currentSize2 = $('h1').css('font-size');
  var currentSize3 = $('h2').css('font-size');
  var currentSize4 = $('h3').css('font-size');
  var currentSize5 = $('h4').css('font-size');
  var currentSize6 = $('h5').css('font-size');
  var currentSize7 = $('h6').css('font-size');
  var currentSize8 = $('span').css('font-size');
  var currentSize9 = $('a').css('font-size');
  var currentSize10 = $('table').css('font-size');
  var currentSize = parseFloat(currentSize)*0.8;
  var currentSize1 = parseFloat(currentSize1)*0.8;
  var currentSize2 = parseFloat(currentSize2)*0.8;
  var currentSize3 = parseFloat(currentSize3)*0.8;
  var currentSize4 = parseFloat(currentSize4)*0.8;
  var currentSize5 = parseFloat(currentSize5)*0.8;
  var currentSize6 = parseFloat(currentSize6)*0.8;
  var currentSize7 = parseFloat(currentSize7)*0.8;
  var currentSize8 = parseFloat(currentSize8)*0.8;
  var currentSize9 = parseFloat(currentSize9)*0.8;
  var currentSize10 = parseFloat(currentSize10)*0.8;
  $('div').css('font-size', currentSize);
  $('p').css('font-size', currentSize1);
  $('h1').css('font-size', currentSize2);
  $('h2').css('font-size', currentSize3);
  $('h3').css('font-size', currentSize4);
  $('h4').css('font-size', currentSize5);
  $('h5').css('font-size', currentSize6);
  $('h6').css('font-size', currentSize7);
  $('span').css('font-size', currentSize8);
  $('a').css('font-size', currentSize9);
  $('table').css('font-size', currentSize10);
  return false;
   });
});
</script>   <style>
.custom-slider {
    position: relative;
    top: 120px;
    height: auto;
    overflow: hidden;
    margin-bottom: 56px;
}
.custom-slider img{
    width:100%;
    height:auto;
    display:block;
}
@media(max-width:767px){
    .custom-slider{
        top:0;
    } 
}
   </style>
   <!-- Slider Revolution -->
	<div class="custom-slider">

  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <!-- <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol> -->

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item">
        <img src="C:\xampp\htdocs\himanshu\project\himanshu_files\jeeadv(1).jpg" alt="MVA" style="width:100%; height:100%;">
     
      </div>
        <div class="item">
        <img src="C:\xampp\htdocs\himanshu\project\himanshu_files\jeeadv.jpg" alt="MVA" style="width:100%; height:100%;">
      
      </div>
        <div class="item">
        <img src="C:\xampp\htdocs\himanshu\project\himanshu_files\jeeadv.jpg" alt="MVA" style="width:100%; height:100%;">
      
      </div>
        <div class="item">
        <img src="C:\xampp\htdocs\himanshu\project\himanshu_files\Class10.jpg" alt="MVA" style="width:100%; height:100%;">
      
      </div>
        <div class="item">
        <img src="C:\xampp\htdocs\himanshu\project\himanshu_files\class12.jpg" alt="MVA" style="width:100%; height:100%;">
      
      </div>
        <div class="item">
        <img src="C:\xampp\htdocs\himanshu\project\himanshu_files\class12.jpg" alt="MVA" style="width:100%; height:100%;">
      
      </div>
        <div class="item">
        <img src="C:\xampp\htdocs\himanshu\project\himanshu_files\Class10.jpg" alt="MVA" style="width:100%; height:100%;">
      
      </div>
        <div class="item">
        <img src="C:\xampp\htdocs\himanshu\project\himanshu_files\jeeadv(1).jpg" alt="MVA" style="width:100%; height:100%;">
      
      </div>
        <div class="item active">
        <img src="C:\xampp\htdocs\himanshu\project\himanshu_files\jeeadv(1).jpg" alt="MVA" style="width:100%; height:100%;">
      
      </div>
        <div class="item">
        <img src="C:\xampp\htdocs\himanshu\project\himanshu_files\jeeadv.jpg" alt="MVA" style="width:100%; height:100%;">
      
      </div>
  
  
  
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="http://www.mvaburhanpur.com/#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="http://www.mvaburhanpur.com/#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
    <!-- Revolution Slider Ends --> 



<div class="bgcolor2 text-center">

    <div class="container">

        <div class="row">

            <div class="col-sm-12">

                <button class="btn-announce"><i class="fa fa-bullhorn"></i></button>

                <div class="announcement">

                      <div class="announcement-text">

                    
                        <span><a href="http://mvaburhanpur.com/User/sample_paper" style="color: #fff;">SAMPLE ENTRANCE EXAM PAPERS</a></span>

                
                        <span><a href="http://mvaburhanpur.com/User/admission" style="color: #fff;">ENTRANCE EXAM SYLLABUS</a></span>

                
                        <span><a href="http://mvaburhanpur.com/User/admission" style="color: #fff;">ADMISSION PROCEDURE</a></span>

                
                        <span><a href="http://mvaburhanpur.com/User/admission" style="color: #fff;">CLICK HEAR FOR MVA CALENDAR</a></span>

                
                    </div>

                    <div class="owl-nav">

                        <span class="owl-left"><i class="fa fa-angle-left"></i></span>

                        <span class="owl-right"><i class="fa fa-angle-right"></i></span>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>



<div class="mb-100">

    <div class="container">

        <div class="row">
 
            <div class="col-sm-7 mt-100">


                <h3 class="heading">Who We <span class="color2">Are</span></h3>

                <p>1884 is the landmark year as the foundation stone was laid 133 years ago for Shri Vaishnav Group of Institutions by compassionate cloth merchants of Vaishnav cult of Indore, which was later rechristened as Shri Vaishnav Sahayak Kapada Market Committee in the year 1934.</p>

                <p>Shri Vaishnav Vidyapeeth Trust believes in taking the nation forward by improving the quality of life of its citizens by continuously working in the sphere of education, health and environment. It has been established to promote education and research in various disciplines through academic institutions for the benefits of all sections of the society, but not with the motive of profit.</p>

                <p>

               Shri Vaishnav Shekshanik Avam Parmarthik Nyas was established under the able guidance of Shri Vaishnav Sahayak Kapada Market Committee in the year 1981. Since then, Nyas has been working relentlessly for the upliftment of the society and country as a whole by providing better technical and professional education, health facilities, schools and other services. Shri Vaishnav Sahayak Kapada Market Committee is running the following Trusts, Colleges, Schools and Institutes of Professional Studies and Research and also rendering social service.<br>

               <br> <i>"WE BELIEVE IN EXCELLENCE"</i>

                </p>

                <div class="clearfix"></div>

                <br>

                <a href="http://mvaburhanpur.com/User/about_mva" class="btn btn-primary btn-sm">Know more <i class="fa fa-long-arrow-right"></i> </a>

            </div>

            <div class="col-sm-5 mt-60">

                <div class="newsletter">

      <h4 class="heading">Contact<span class="color2"> Us</span></h4>



                    <form method="post" action="#" id="contactus">

                <div class="row">

                    <div class="col-sm-12">

                        <div class="form-group">


                            <input id="contact-name" type="text" class="form-control" name="name" required="" placeholder="Please enter your name">

                        </div>

                    </div>

                </div>

                <div class="row">

                    <div class="col-sm-6">

                        <div class="form-group">

                            <input id="contact-number" type="text" class="form-control" name="contact" required="" placeholder="Please enter your contact number" onkeypress="return isNumberKey(event)" maxlength="14">

                        </div>

                    </div>

                    <div class="col-sm-6">

                        <div class="form-group">

                            <input id="contact-email" type="email" class="form-control" name="email" required="" placeholder="Please enter your email">

                        </div>

                    </div>

                </div>

                <div class="row">

                    <div class="col-sm-12">

                        <div class="form-group">

                            <textarea id="contact-message" class="form-control" rows="3" name="quiry" required="" placeholder="Message"></textarea>

                        </div>

                    </div>

                </div>

                    <span id="status"></span>

                    <center><input type="submit" name="submit" value="Submit" class="btn btn-primary"></center>

<?php

$a=$_POST['name'];

$b=$_POST['contact'];

$c=$_POST['email'];

$d=$_POST['quiry'];

 if(isset($_POST['submit']))
{
                           $link=mysqli_connect('localhost','root','','cmc');
                           $qry="insert into main values('','$a','$b','$c','$d')";
                           mysqli_query($link,$qry);
                                  }
                                 ?>

                    <!-- <button type="submit" name="submit" class="btn btn-primary">Submit</button> -->

            </form>

                </div>

            </div>

        </div>

    </div>

</div>

<!-- 

<div class="bgcolor3 pt-100 pb-100">

    <div class="container">

        <div class="row">

            <div class="col-sm-12">

                <h2 class="heading text-center">Macro Vision <span class="color2">Academy</span>

                    <span class="sub-heading">"MVA - A synchronisation of CBSE Curriculum with preparatiionof competive examination with innovatons in technology"</span>

                    <span class="icon-divider"></span>

                </h2>

            </div>

        </div>

        <div class="row">

            <div class="col-sm-4">

                <div class="icon-box-1">

                    <div class="icon-box-icon">

                        <i class="fa fa-calendar-check-o"></i>

                    </div>

                    <div class="icon-box-content">

                        <a href="http://mvaburhanpur.com/User/recent_update"><h5 class="heading icn-mar">Recent Updates</h5></a>

                        

                    </div>

                </div>

            </div>

            <div class="col-sm-4">

                <div class="icon-box-1">

                    <div class="icon-box-icon">

                        <i class="fa fa-picture-o" aria-hidden="true"></i>

                    </div>

                    <div class="icon-box-content">

                        <a href="http://mvaburhanpur.com/User/activities"><h5 class="heading icn-mar">Activities</h5></a>

                    </div>

                </div>

            </div>

            <div class="col-sm-4">

                <div class="icon-box-1">

                    <div class="icon-box-icon">

                        <i class="fa fa-picture-o" aria-hidden="true"></i>

                    </div>

                    <div class="icon-box-content">

                        <a href="http://mvaburhanpur.com/User/gallery"><h5 class="heading icn-mar">Gallery</h5></a>

                    </div>

                </div>

            </div>

        </div>

        <div class="row">

            <div class="col-sm-4">

                <div class="icon-box-1">

                    <div class="icon-box-icon">

                        <i class="fa fa-graduation-cap" aria-hidden="true"></i>

                    </div>

                    <div class="icon-box-content">

                        <a href="http://mvaburhanpur.com/User/alumni"><h5 class="heading icn-mar">Alumni</h5></a>

                    </div>

                </div>

            </div>

            <div class="col-sm-4">

                <div class="icon-box-1">

                    <div class="icon-box-icon">

                        <i class="fa fa-newspaper-o" aria-hidden="true"></i>

                    </div>

                    <div class="icon-box-content">

                        <a href="http://mvaburhanpur.com/User/media"><h5 class="heading icn-mar">Media Advertisements</h5></a>

                    </div>

                </div>

            </div>

            <div class="col-sm-4">

                <div class="icon-box-1">

                     <div class="icon-box-icon">

                        <i class="fa fa-users" aria-hidden="true"></i>

                    </div>

                    <div class="icon-box-content">

                        <a href="http://mvaburhanpur.com/User/teaching_staff"><h5 class="heading icn-mar">Teaching Staff</h5></a>

                    </div>

                </div>

            </div>                

        </div>

        <div class="row">

            <div class="col-sm-4">

                <div class="icon-box-1 icn-mar">

                    <div class="icon-box-icon">

                        <i class="fa fa-line-chart" aria-hidden="true"></i>

                    </div>

                    <div class="icon-box-content">

                        <a href="http://mvaburhanpur.com/User/result"><h5 class="heading icn-mar">Result</h5></a>

                    </div>

                </div>

            </div>

            <div class="col-sm-4">

                <div class="icon-box-1 icn-mar">

                    <div class="icon-box-icon">

                        <i class="fa fa-phone" aria-hidden="true"></i>

                    </div>

                    <div class="icon-box-content">

                        <a href="http://mvaburhanpur.com/User/contact_us"><h5 class="heading icn-mar">Contact Us</h5></a>

                    </div>

                </div>

            </div>

            <div class="col-sm-4">

                <div class="icon-box-1 icn-mar">

                    <div class="icon-box-icon">

                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>

                    </div>

                    <div class="icon-box-content">

                        <a href="http://mvaburhanpur.com/User/online_enquiry"><h5 class="heading icn-mar">Enquiry</h5></a>

                    </div>

                </div>

            </div>                

        </div>

        <div class="row">

            <div class="col-sm-4">

                <div class="icon-box-1 icn-mar">

                    <div class="icon-box-icon">

                        <i class="fa fa-industry" aria-hidden="true"></i>

                    </div>

                    <div class="icon-box-content">

                        <a href="http://mvaburhanpur.com/User/facilities"><h5 class="heading icn-mar">Facilities</h5></a>

                    </div>

                </div>

            </div>

            <div class="col-sm-4">

                <div class="icon-box-1 icn-mar">

                    <div class="icon-box-icon">

                        <i class="fa fa-bullhorn" aria-hidden="true"></i>

                    </div>

                    <div class="icon-box-content">

                        <a href="http://mvaburhanpur.com/User/announcement"><h5 class="heading icn-mar">Announcements</h5></a>

                    </div>

                </div>

            </div>

            <div class="col-sm-4">

                <div class="icon-box-1 icn-mar">

                    <div class="icon-box-icon">

                        <i class="fa fa-handshake-o" aria-hidden="true"></i>

                    </div>

                    <div class="icon-box-content">

                        <a href="http://mvaburhanpur.com/User/career"><h5 class="heading icn-mar">Career with us</h5></a>

                    </div>

                </div>

            </div>                

        </div>

    </div>

</div>    

 -->



<div class="gallery">

    <div class="container-fluid">

        <div class="row">

            <div class="gallery-overlay">

                <h2 class="gallery-heading">Life At SVVV</h2>

            </div>

          
            <div class="col-sm-3 no-gutter">

                <div class="img-box">

                  <a href="file:///A:/project/himanshu_files/88.jpg" data-gal="prettyPhoto[galleryName]" class="img-zoom"><i class="fa fa-search"></i></a>

                  <img src="file:///A:/project/himanshu_files/88.jpg" alt="" class="img-responsive">

              </div>

          </div>

          <div class="col-sm-3 no-gutter">

            <div class="img-box">

              <a href="file:///A:/project/himanshu_files/08.jpg" data-gal="prettyPhoto[galleryName]" class="img-zoom"><i class="fa fa-search"></i></a>

              <img src="file:///A:/project/himanshu_files/08.jpg" alt="" class="img-responsive">

          </div>

          <div class="img-box">

              <a href="file:///A:/project/himanshu_files/07.jpg" data-gal="prettyPhoto[galleryName]" class="img-zoom"><i class="fa fa-search"></i></a>

              <img src="file:///A:/project/himanshu_files/07.jpg" alt="" class="img-responsive">

          </div>                    

      </div>

      <div class="col-sm-3 no-gutter">

        <div class="img-box">

          <a href="file:///A:/project/himanshu_files/06.jpg" data-gal="prettyPhoto[galleryName]" class="img-zoom"><i class="fa fa-search"></i></a>

          <img src="file:///A:/project/himanshu_files/06.jpg" alt="" class="img-responsive">

      </div>

      <div class="img-box">

          <a href="file:///A:/project/himanshu_files/44.jpg" data-gal="prettyPhoto[galleryName]" class="img-zoom"><i class="fa fa-search"></i></a>

          <img src="file:///A:/project/himanshu_files/44.jpg" alt="" class="img-responsive">

      </div>                    

  </div>

  <div class="col-sm-3 no-gutter">

    <div class="img-box">

      <a href="file:///A:/project/himanshu_files/337X4841.jpg" data-gal="prettyPhoto[galleryName]" class="img-zoom"><i class="fa fa-search"></i></a>

      <img src="file:///A:/project/himanshu_files/337X4841.jpg" alt="" class="img-responsive">

  </div>

</div>                

</div>

</div>

</div> 




<div class="mt-80 mb-80">

    <div class="container">

        <div class="row">

            <div class="col-sm-12">

                <div class="row">

                    <div class="facts">


                        

                        <div class="fact col-sm-4">

                            <span class="head">

                                <span class="count" data-from="0" data-to="68" data-speed="3000"></span> Acre Campus

                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>



<div class="clearfix"></div>


<div class="container mb-100">

    <div class="row">

        <div class="col-sm-12">

            <h2 class="heading text-center">We're making a <span class="color2">Difference</span>

                <span class="sub-heading"><p>SVVV is an institude imparting quality education to the youth of india in every possible field.</p>
</span>

                <span class="icon-divider"></span>

            </h2>

        </div>

    </div>    

    <div class="row mt-20">

        <div class="col-sm-6">

            <img src="C:\xampp\htdocs\himanshu\project\himanshu_files\Admission002.JPG" class="img-responsive" alt="" width="555" height="370">

        </div>

        <div class="col-sm-6">

            <div class="accordion-2">

                <div class="panel-group" id="a2" role="tablist" aria-multiselectable="true">

                   <div class="panel panel-default">

                        <div class="panel-heading" role="tab" id="a2heading1">

                            <h4 class="panel-title">

                                <a role="button" data-toggle="collapse" data-parent="#a2" href="#a2body1" aria-expanded="false" aria-controls="a2body1" class="collapsed">

                                    What's so awesome about SVVV?
                                </a>

                            </h4>

                        </div>

                        <div id="a2body1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="a2heading1" aria-expanded="false" style="height: 0px;">

                            <div class="panel-body">

                                All over year different types of events are held so each and every student can get an opportunity to show his/her talent in other activities.list of events are-spardha(sports media),kalakriti and vishwankan(fine arts),spandhan(annual fest),MUN(international level of competition) and many countless events, not even a week is free.In terms of scholarship it provides 50% scholarship
according to the merit list of 12th class and jee mains.bank of Maharashtra is the partner of this college which easily provided the loans in education and startup.
 
                            </div>

                        </div>

                    

                    </div>

                   <div class="panel panel-default">

                        <div class="panel-heading" role="tab" id="a2heading2">

                            <h4 class="panel-title">

                                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#a2" href="http://www.mvaburhanpur.com/#a2body2" aria-expanded="false" aria-controls="a2body2">

                                   Why are we the best?
                              </a>

                          </h4>

                      </div>

                      <div id="a2body2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="a2heading2" aria-expanded="false">

                        <div class="panel-body">

                           In this college, the best part is about faculties.All of them are well qualified with some special courses,most of the are complicated their higher education.Teachers with their knowledge talent they teach their different subject.Teachers got their intresting subject to share with students and always helpful in a polite way.

                        </div>

                    </div>

                </div>

                <div class="panel panel-default">

                    <div class="panel-heading" role="tab" id="a2heading3">

                        <h4 class="panel-title">

                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#a2" href="http://www.mvaburhanpur.com/#a2body3" aria-expanded="false" aria-controls="a2body3">

                              What makes SVVV a Unique organisation?
                          </a>

                      </h4>

                  </div>

                  <div id="a2body3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="a2heading3" aria-expanded="false">

                    <div class="panel-body">

                        Our institution is unique as it has its own uniquely designed 
syllabus in such a way that makes it easier to learn and understand 
and subjects beign chosen in such a way that will be helpful with the field
a student opts for.For instance unlike RGPV colleges in indore,the first year student in RGPV
colleges study,useless subjects like chemistry,engineering drawing and applied physics,environmental studies which have nothing to do with coding.
but here the course for the students is changed immensely and we don't have such subjects,we have data structure and algorithms and object orientedprogramming and computer system organisation as our subjects.
                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

</div>

</div>



<div class="clearfix"></div>



<div class="container-fluid mb-100">

    <div class="row">

         
        <div class="tweets" data-parallax="scroll" data-image-src="http://mvaburhanpur.com/uploads/home__student3.jpg" data-speed="0.4">

        
            <p style="text-align: center;">232 SELECTIONS IN JEE MAINS 2018-2019</p>

            
            <p style="text-align: center;">38 SELECTIONS IN NTSE STAGE-2</p>

            
            <p style="text-align: center;">100% RESULTS IN CLASS XII CBSE BOARD</p>

            
            <p style="text-align: center;">&gt;96 STUDENTS GOT MORE THAN 90% IN  CLASS XII CBSE BOARD EXAM</p>

            
            <p style="text-align: center;">&gt;278 STUDENTS GOT MORE THAN 80% IN  CLASS XII CBSE BOARD EXAM</p>

            
            <p style="text-align: center;">IN NTSE-2019 HIGHEST NUMBER OF SELECTIONS FROM ANY SCHOOL IN INDIA</p>

            
            <p style="text-align: center;">100% RESULTS IN CLASS X CBSE BOARD</p>

            
            <p style="text-align: center;">&gt;111 STUDENTS GOT MORE THAN 90% IN CLASS X CBSE BOARD EXAM</p>

            
            <p style="text-align: center;">&gt;252 STUDENTS GOT MORE THAN 80% IN CLASS X CBSE BOARD EXAM</p>

            
        </div>

    </div>

</div>



<div class="clearfix"></div>

<!-- 

<div class="container">

    <div class="row">

        <div class="col-sm-12">

            <h2 class="heading text-center">Our Management <span class="color2">Member</span>

                <span class="sub-heading">Our highly qualified teachers put in their best efforts for outstanding results in both studies and co-curricular activities.</span>

                <span class="icon-divider"></span>

            </h2>

        </div>

        
        <div class="col-sm-4">

            <div class="teacher-card">

                <img src="http://mvaburhanpur.com/uploads/faculty/DSC04650.JPG" class="teacher-img img-responsive" alt="" style="width: 350px; height: 350px;">

                <div class="teacher-detail">

                    <h5 class="heading">MR.ANAND PRAKASH CHOUKSEY</h5>

                    <span class="position">SOCIETY SECRETARY </span><br>

                    <span class="position">M.Sc(MATHS)MERIT SCHOLAR</span>

                </div>

            </div>

        </div>



    
        <div class="col-sm-4">

            <div class="teacher-card">

                <img src="http://mvaburhanpur.com/uploads/faculty/DSC04687_filtered.jpg" class="teacher-img img-responsive" alt="" style="width: 350px; height: 350px;">

                <div class="teacher-detail">

                    <h5 class="heading">MRS.MANJUSHA CHOUKSEY</h5>

                    <span class="position">SOCIETY  PRESIDENT</span><br>

                    <span class="position">M.Sc(BOTANY) GOLD MEDALIST, B.Ed</span>

                </div>

            </div>

        </div>



    
        <div class="col-sm-4">

            <div class="teacher-card">

                <img src="http://mvaburhanpur.com/uploads/faculty/Parmar_Sir_01.jpg" class="teacher-img img-responsive" alt="" style="width: 350px; height: 350px;">

                <div class="teacher-detail">

                    <h5 class="heading">MR. JASVIR SINGH PARMAR</h5>

                    <span class="position">PRINCIPAL</span><br>

                    <span class="position">M.A. ENGLISH,B.ED</span>

                </div>

            </div>

        </div>



     

    </div>

</div>    

 -->

<div class="clearfix"></div>






<div class="mb-80">

    <div class="bgcolor3">

        <div class="container">

            <div class="row">

                <div class="col-sm-12" style="margin-top: 30px;">

                    <center><h3 class="heading">What Alumni<span class="color2">/Student Say</span></h3></center>

                    <div class="testimonials">
                    
          
                        
                        <div class="testimonial-item">

                           
                            <div class="testimonial-text" style="font-size: 20px !important;">

                                <p>The college has a rich source of library.Whole campus id provided with wifi facilities.Classrooms are big and well maintained.Teachers are well qualified and helpful course curriculum is well designed and made according to the modern industries requirments.    </p>

                                <span class="testimonial-by">Sachin[B.Tech(CSE-BDA)]</span>

                            </div>

                        </div>
 
                        <div class="testimonial-item">

                           
                            <div class="testimonial-text" style="font-size: 20px !important;">

                                <p>College managment has mostly been supportive whenever there was a need.It was analyzed and proper measures were taken.Overall placement of the college is amazing.With industrial tie-ups with corporates giants like TCS,IBM,Redhat,etc. there are not many students left unplaced.The average placement package is about 3-5 lacs. </p>

                                <span class="testimonial-by">Anshuman Bhatnagar(BE)[Alumni-2016]</span>

                            </div>

                        </div>
                                                <!-- <div class="testimonial-item">

                            <img src="http://mvaburhanpur.com/front_theme/images/test2.png" class="testimonial-img" alt="" style="padding: 70px !important;">

                            <div class="testimonial-text" style="font-size: 20px !important;">

                                <p>College managment has mostly been supportive whenever there was a need.It was analyzed and proper measures were taken.Overall placement of the college is amazing.With industrial tie-ups with corporates giants like TCS,IBM,Redhat,etc. there are not many students left unplaced.The average placement package is about 3-5 lacs.  </p>

                                <span class="testimonial-by">Anshuman Bhatnagar(BE)[Alumni-2016]</span>

                            </div>

                        </div> -->

                    </div>

                    <div class="owl-nav">

                        <span class="owl-left"><i class="fa fa-angle-left"></i></span>

                        <span class="owl-right"><i class="fa fa-angle-right"></i></span>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <div class="clearfix"></div>    


   

 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">×</button>
          <h4 class="modal-title">
          <img style="width: 100%;" src="file:///A:/project/himanshu_files/jeeadv(1).jpg">
          </h4>
        </div>
        <div class="modal-body">
          <p>JEE ADVANCED 2019</p>

          <p>URL: <a href="http://www.mvaburhanpur.com/"></a></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
$(document).ready(function(){
setTimeout(function(){ 
$('#myModal').modal({
        show: 'false'
    }); 
}, 2000);
});
</script>


   <script type="text/javascript">jssor_1_slider_init();</script>

   
   <script>

    // Set the date we're counting down to

    var countDownDate = new Date(" ").getTime();

    //alert(countDownDate);

    // Update the count down every 1 second

    var x = setInterval(function() {

    // Get todays date and time

    var now = new Date().getTime();    

    // Find the distance between now an the count down date

    var distance = countDownDate - now;    

    // Time calculations for days, hours, minutes and seconds

    var days = Math.floor(distance / (1000 * 60 * 60 * 24));

    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));

    var seconds = Math.floor((distance % (1000 * 60)) / 1000);    

    // Output the result in an element with id="demo"

    document.getElementById("demo").innerHTML = days + "d " + hours + "h "

    + minutes + "m " + seconds + "s ";    

    // If the count down is over, write some text 

    if (distance < 0) {

        clearInterval(x);

        document.getElementById("demo").innerHTML = "Event Completed";

    }

}, 1000);


</script>  
  <footer class="footer">         <!-- Footer -->
        <div class="footer-pri">            <!-- Primary Footer -->
            <div class="container-fluid">
                <div class="row">
                   <!--  <div class="col-sm-4 footer-widget">           
                        <h5 class="heading inverse">Recent <span class="color2">Blog</span></h5>
                        <ul class="blog-thumbnail">
                            <li class="entry">         
                                <div class="entry-content">
                                    <h4 class="entry-header"><a href="blog-single.html">What it takes to be National Best ?</a></h4>
                                    <p class="entry-text">A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.                                     </p>
                                </div>
                            </li>
                            <li class="entry">          
                                <div class="entry-content">
                                    <h4 class="entry-header"><a href="blog-single.html">How do we achieve 100% success rate ?</a></h4>
                                    <p class="entry-text">A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.                                     </p>
                                </div>
                            </li>
                        </ul>
                    </div> -->
                    <div class="col-sm-3 footer-widget">            <!-- Footer Widget - Quick Links -->
                        <h5 class="heading inverse">Useful <span class="color2">Links</span></h5>
                        <ul class="quick-links">
                            <li><a href="https://en.wikipedia.org/wiki/Indore" target="_blank">About Indore</a></li>
                            <li><a href="http://indiatoday.intoday.in/" target="_blank">Latest News</a></li>
                            <li><a href="http://india.gov.in/services/get-help-helpline" target="_blank">Online Emergency Services</a></li>
                            <li><a href="http://www.justdial.com/" target="_blank">Multiple Services</a></li>
                            <img src="C:\xampp\htdocs\himanshu\project\himanshu_files\Apple_School.png" class="img-responsive" style="width: 60%;">
                        </ul>
                    </div>



                     <div class="col-sm-3 footer-widget">            <!-- Footer Widget - Quick Links -->
                        <h5 class="heading inverse">Quick <span class="color2">Links</span></h5>
                        <ul class="quick-links">
                            <li><a href="file:///C:/xampp/htdocs/himanshu/project/whyus.html">Career with us</a></li>
                            
                            <li><a href="http://mvaburhanpur.com/User/activities">Activities</a></li>
                            
                            
                            <li><a href="https://www.youtube.com/watch?v=U-caGXd25XI">Virtual Tour</a></li>
                        </ul>
                        
                    </div>
                    <!-- <div class="col-sm-4 footer-widget">         
                        <h5 class="heading inverse">Affiliations &amp; <span class="color2">Awards</span></h5>
                        <ul class="affiliations">
                            <li><img src="images/university-1.png" class="img-responsive" alt=""></li>
                            <li><img src="images/university-2.png" class="img-responsive" alt=""></li>
                        </ul>
                    </div> -->
                    <div class="col-sm-3 footer-widget">            <!-- Footer Widget - Contact Info -->
                        <h5 class="heading inverse">Contact  <span class="color2">Us</span></h5>
                        <address>
                        
                            <strong>Shri Vaishnav Vidyapeeth Vishwavidyalaya</strong>
                                <br>
                                <strong>Campus :</strong> Indore – Ujjain Road, Indore – 453111
                                <br>
                                <strong>City Office :</strong> Shri Vaishnav Vidya Parisar, 177 Jawahar Marg, Indore(M.P.)
                        </address>
                        <a class="phone" href="file:///A:/project/himanshu.html">Mobile No. (+91)9522237602,9522237604,9522237605,9522237606,9522237607</a><br>
<a class="phone" href="file:///A:/project/himanshu.html">Toll Free No.:-1800-233-9111</a><br>
                        
                        <a href="mailto:test@example.com" class="email"><i class="fa fa-envelope fa-fw"></i> admission@svvv.edu.in</a>
                    </div>
                    <div class="col-sm-3 footer-widget">            <!-- Footer Widget - Contact Info -->
                        <div class="newsletter-area">
                    <!--
                    <iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2FIperfectOnline&amp;width=280&amp;height=220&amp;colorscheme=light&amp;show_faces=true&amp;header=true&amp;stream=false&amp;show_border=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:280px; height:230px;" allowTransparency="true"></iframe>
                    -->
                   <iframe src="./newhimanshu_files/likebox.html" scrolling="no" frameborder="0" class="fb-plugins" allowtransparency="true" height="230px;"></iframe>
                </div>
                
            </div>
                   	</div>
                </div>



           
        </div>
        <div class="footer-sec">            <!-- Secondary Footer -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-4">
                        <span class="copyright">© Copyright Shri Vaishnav Vidhyapeet Vishwavidhyalay</span>           <!-- Copyright Text -->
                    </div>
                    <div class="col-sm-4">
                        <span class="copyright">© 2017 Designed and Developed by <b>Himanshu And Team</b></a></span>
                    </div>
                    <div class="col-sm-4 text-center">
                        <ul class="social">          <!-- Social Media Links -->
                            <li><a href="http://www.mvaburhanpur.com/#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="http://www.mvaburhanpur.com/#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="http://www.mvaburhanpur.com/#"><i class="fa fa-pinterest-p"></i></a></li>
                            <li><a href="http://www.mvaburhanpur.com/#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="http://www.mvaburhanpur.com/#"><i class="fa fa-reddit-alien"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
	<!-- Modal -->
<!-- 	 <div class="modal fade" id="modal1" data-open-onload="true" data-open-delay="2500" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <div class="modal-body" style="background-image:url('images/modal-background.jpg'); background-size:cover">
                    <div class="row">
                        <div class="col-md-5 pull-right bginverse pt-20 pb-20">
                            <h4 class="heading">Subscribe to our Newsletter!</h4>
                            <p>Trust us, you will absolutely love our newletter feed!</p>
                            <br/>
                            <form>
                                <div class="form-group">
                                    <input id="contact-name" type="text" class="form-control">
                                    <label for="contact-name">Your Name</label>
                                </div>
                                <div class="form-group">
                                    <input id="contact-email" type="text" class="form-control">
                                    <label for="contact-email">Email ID</label>
                                </div>
                                <button type="submit" class="btn btn-primary">Subscribe</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
     -->
    <div id="back"><i class="fa fa-angle-up"></i></div>   
    <div id="switch" style="right:0px;">
        <ul>
            <li id="yellow"></li>
            <li id="blue"></li>
            <li id="red"></li>
            <li id="green"></li>
        </ul>
    </div>     <!-- Back To Top -->
    <!--jQuery Version 2.2.1-->

    <script src="file:///A:/project/himanshu_files/jquery.min.js.download" type="text/javascript"></script>
    <!--Bootstrap Framework version 3.3.7-->
    <script src="file:///A:/project/himanshu_files/bootstrap.min.js.download" type="text/javascript"></script>    
    <!--Slider Revolution version 5.0-->
    <script type="text/javascript" src="file:///A:/project/himanshu_files/jquery.themepunch.tools.min.js.download"></script>
    <script type="text/javascript" src="file:///A:/project/himanshu_files/jquery.themepunch.revolution.min.js.download"></script>    
    <!-- Include only when working on Local system. Not required on server -->
    <script type="text/javascript" src="file:///A:/project/himanshu_files/revolution.extension.parallax.min.js.download"></script>   
    <script type="text/javascript" src="file:///A:/project/himanshu_files/revolution.extension.video.min.js.download"></script>
    <script type="text/javascript" src="file:///A:/project/himanshu_files/revolution.extension.slideanims.min.js.download"></script>
    <script type="text/javascript" src="file:///A:/project/himanshu_files/revolution.extension.navigation.min.js.download"></script>
    <script type="text/javascript" src="file:///A:/project/himanshu_files/revolution.extension.layeranimation.min.js.download"></script>    
    <!-- Countdown Timer Version 2.1.0-->
    <script src="file:///A:/project/himanshu_files/jquery.countdown.min.js.download" type="text/javascript"></script>    
    <!-- Owl Carousel Version 2.0.0 -->
    <script src="file:///A:/project/himanshu_files/owl.carousel.min.js.download" type="text/javascript"></script>    
    <!-- CountTo -->
    <script src="file:///A:/project/himanshu_files/jquery.countTo.js.download" type="text/javascript"></script>    
    <!-- Appear -->
    <script src="file:///A:/project/himanshu_files/jquery.appear.js.download" type="text/javascript"></script>        
    <!--Pretty Photo Version 3.1.6-->
    <script src="file:///A:/project/himanshu_files/jquery.prettyPhoto.js.download" type="text/javascript"></script>    
    <!-- Parallax Version 1.4.2 -->
    <script src="file:///A:/project/himanshu_files/parallax.js.download" type="text/javascript"></script>	
    <!--Educomp Custom Script-->
    <script src="file:///A:/project/himanshu_files/main.js.download" type="text/javascript"></script>
	<script src="file:///A:/project/himanshu_files/color-switch.js.download" type="text/javascript"></script>
    <script src="file:///A:/project/himanshu_files/jquery.imageview.js.download"></script>
    <link href="file:///A:/project/himanshu_files/jquery-ui.css" rel="stylesheet">
      <script src="file:///A:/project/himanshu_files/jquery-1.10.2.js.download"></script>
      <script src="file:///A:/project/himanshu_files/jquery-ui.js.download"></script>
    <script>
    $('#iv').imageview();
    </script>

    <!-- <script type="text/javascript" src="htts://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>    -->
<script>
    $( document ).ready(function() {
    function sliceSize(dataNum, dataTotal) {
        alert ('hello');

  return (dataNum / dataTotal) * 360;
}
function addSlice(sliceSize, pieElement, offset, sliceID, color) {
  $(pieElement).append("<div class='slice "+sliceID+"'><span></span></div>");
  var offset = offset - 1;
  var sizeRotation = -179 + sliceSize;
  $("."+sliceID).css({
    "transform": "rotate("+offset+"deg) translate3d(0,0,0)"
  });
  $("."+sliceID+" span").css({
    "transform"       : "rotate("+sizeRotation+"deg) translate3d(0,0,0)",
    "background-color": color
  });
}
function iterateSlices(sliceSize, pieElement, offset, dataCount, sliceCount, color) {
  var sliceID = "s"+dataCount+"-"+sliceCount;
  var maxSize = 179;
  if(sliceSize<=maxSize) {
    addSlice(sliceSize, pieElement, offset, sliceID, color);
  } else {
    addSlice(maxSize, pieElement, offset, sliceID, color);
    iterateSlices(sliceSize-maxSize, pieElement, offset+maxSize, dataCount, sliceCount+1, color);
  }
}
function createPie(dataElement, pieElement) {
  var listData = [];
  $(dataElement+" span").each(function() {
    listData.push(Number($(this).html()));
  });
  var listTotal = 0;
  for(var i=0; i<listData.length; i++) {
    listTotal += listData[i];
  }
  var offset = 0;
  var color = [
    "cornflowerblue", 
    "olivedrab", 
    "orange", 
    "tomato", 
    "crimson", 
    "purple", 
    "turquoise", 
    "forestgreen", 
    "navy", 
    "gray"
  ];
  for(var i=0; i<listData.length; i++) {
    var size = sliceSize(listData[i], listTotal);
    iterateSlices(size, pieElement, offset, i, 0, color[i]);
    $(dataElement+" li:nth-child("+(i+1)+")").css("border-color", color[i]);
    offset += size;
  }
}
createPie(".pieID.legend", ".pieID.pie");

});
</script>


<!-- gallery end -->



 </body></html>
<?php
$link=mysqli_connect("localhost","root","","cmc");
$a=$_POST['name'];
$b=$_POST['mobile'];
$c=$_POST['email'];
$d=$_POST['message'];
if(isset($_POST['submit']))
{
$qry="insert into t10 values('','$a','$b','$c','$d')";
$res1=mysqli_query($link,$qry);
}
 
?>